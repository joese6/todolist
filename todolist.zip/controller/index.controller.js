export const indexController = {
  index: async (req, res) => {
    res.render("pages/index");
  },
};
